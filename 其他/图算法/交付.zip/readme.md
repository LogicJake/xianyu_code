# 任务一数据集
* test.txt: 有环的有向图
* test2.txt: 无环的有向图

# 任务二数据集介绍
* bitcoin.txt：http://snap.stanford.edu/data/soc-sign-bitcoin-alpha.html
* email.txt：http://snap.stanford.edu/data/email-Eu-core.html
* facebook.txt：http://snap.stanford.edu/data/ego-Facebook.html
